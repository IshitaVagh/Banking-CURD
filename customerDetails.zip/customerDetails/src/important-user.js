import {LitElement,html,css} from 'lit-element'

export default class ImportantUser extends LitElement{
    constructor(){
        super();
    }
    static get styles(){
        return css`            
        .userCard{
                display:inline-block;
                font:14px;
                color:#000;
                padding:10px;
                text-align:center;
                border-radius:10px;
                width:200px;
                transition:all .4s ease-in-out;
                margin:10px;
                -webkit-box-shadow:0px 4px 77px -17px rgb(0,0,0,0.36);
            }
            .uesrImg{
                width:50px;
                border-radious:50px;
            }
            .userName p:first-of-type,.CompanyName p:first-of-type,.Address p:first-of-type{
                font-size:14px;
                color:#000;
                margin:10px;
                font-weight:700;
            }
            .userName p:last-of-type,.CompanyName p:last-of-type,.Address p:last-of-type{
                font-size:12px;
                color:#dd0;
                margin:2px;
            }
            .userListBar{
                display:inline-flex;
                font:14px;
                color:#000;
                padding:10px;
                text-align:center;
                border-radius:10px;
                width:93%;
                transition:all .4s ease-in-out;
                margin:10px;
                -webkit-box-shadow:0px 4px 77px -17px rgb(0,0,0,0.36);
            }
        `
    }
    render(){
        return html`
        <div class="userDetails">
        <h2> User Details </h2>
            <div class="userCard">
                <img src="../img/user.png" class="uesrImg">
                <div class="userName">
                    <p> Ishita Vagh </p>
                    <p> Full Name </p>
                </div>
                <div class="CompanyName">
                    <p> Cognizant </p>
                    <p> Company  </p>
                </div>
                <div class="Address">
                    <p> 7/4299, Galemandi, Sutharfaliya, Surat-03 </p>
                    <p> Address </p>
                </div>
            </div>
            <div class="userCard">
                <img src="../img/user2.png" class="uesrImg">
                <div class="userName">
                    <p> Mayank Vagh </p>
                    <p> Full Name </p>
                </div>
                <div class="CompanyName">
                    <p> Zensar </p>
                    <p> Company  </p>
                </div>
                <div class="Address">
                    <p> 7/4299, Galemandi, Sutharfaliya, Surat-03 </p>
                    <p> Address </p>
                </div>
            </div>
            <div class="userCard">
                <img src="../img/user3.png" class="uesrImg">
                <div class="userName">
                    <p> Jenish Vagh </p>
                    <p> Full Name </p>
                </div>
                <div class="CompanyName">
                    <p> Cognizant </p>
                    <p> Company  </p>
                </div>
                <div class="Address">
                    <p> 7/4299, Galemandi, Sutharfaliya, Surat-03 </p>
                    <p> Address </p>
                </div>
            </div>
            <div class="userCard">
                <img src="../img/user4.png" class="uesrImg">
                <div class="userName">
                    <p> Seema Vagh </p>
                    <p> Full Name </p>
                </div>
                <div class="CompanyName">
                 <p> Infosys </p>
                 <p> Company  </p>
                </div>
                <div class="Address">
                    <p> 7/4299, Galemandi, Sutharfaliya, Surat-03 </p>
                    <p> Address </p>
                </div>
            </div>
        </div>
        <div class="userList">
        <div class="userListBar">
            <img src="../img/user4.png" class="uesrImg">
            <div class="userName">
                <p> Seema Vagh </p>
                <p> Full Name </p>
            </div>
            <div class="CompanyName">
            <p> Infosys </p>
            <p> Company  </p>
            </div>
            <div class="Address">
                <p> 7/4299, Galemandi, Sutharfaliya, Surat-03 </p>
                <p> Address </p>
            </div>
        </div>
    </div>
        `
    }
}
customElements.define('important-user',ImportantUser)