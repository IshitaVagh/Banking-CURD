import {LitElement,html,css} from 'lit-element';
export default class SideNav extends LitElement{
    static get styles(){
        return css`
        .sideNavBar{
            width:250px;
            height:100Vh;
            background-color: #0e0e2d;
            padding:10px 20px;
        }
        .logo{
            margin:15px;
            text-align:center;
        }
        .logo img{
            width:100px;
        }
        .nav a{
            display:block;
            color:#fff;
            text-decoration:none;
            padding: 10px;
        }
        .nav a:first-of-type{
            margin:0 35px;
        }
        .nav .nav-icon{
            margin:10px;
        }
    `
    }
    constructor(){
        super();
    }
    render(){
        return html`
        <section class="sideNavBar">
        <div class="logo"> 
          <img src="../img/logo.png">
        </div>
        <div class="nav">
          <a href="#"> Home </a>
          <a href="#"><span class="nav-icon"> + </span>  Admin </a>
          <a href="#"><span class="nav-icon"> + </span>  Accounts </a>
        </div>
      </section>
        `;
    }
}

customElements.define("side-nav",SideNav)