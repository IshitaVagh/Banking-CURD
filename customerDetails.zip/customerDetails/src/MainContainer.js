import {LitElement,html,css} from 'lit-element';
import {DilePages} from 'dile-pages';
import ImportantUser from '../src/important-user';
import CreateUser from '../src/create-user';
export default class MainContainer extends LitElement{
    constructor(){
        super();
        this.selectedPage = 0;
    }
    static get styles(){
        return css`
            .contentBar{
              padding:20px;
              background:#fff;
            }
           
        `;
    }
    static get property(){
        return{
            seletedPage:{type:Number,
                reflect: true,
                 hasChanged(newVal, oldVal) {
                    console.log("Property changed");
                  }
            
            },
            listUserDetails: {type:Array}
        }
    }
    render(){
        return html`
        <dile-pages id="pages" selected=${this.selectedPage}>
        <section class="contentBar" name="userList">
          <important-user selectedPage=${this.selectedPage} listUserDetails=${this.listUserDetails}></important-user>
         </section> 
         <section class="contentBar" name="createUser">
          <create-user selectedPage=${this.selectedPage} listUserDetails=${this.listUserDetails}></create-user>
        </section>    
        <section class="contentBar" name="userDetails">
         User Details
       </section>    
      </dile-pages>
     
        `;
    }

}
customElements.define('main-container',MainContainer);