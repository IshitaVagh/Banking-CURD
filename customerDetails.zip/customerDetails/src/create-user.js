import {LitElement,html,css} from 'lit-element'
export default class CreateUser extends LitElement{
    constructor(){
        super();
        this.getuserDetails = this.getuserDetails.bind(this);
        this.userDetails={};
        this.listUserDetails=[];
    }
    static get styles(){
        return css`
            .user-details-form{
                display:grid;
                grid-template-columns: 1fr 1fr 1fr 1fr;
                padding:15px;

            }
            .formContainer label{
                color:#000;
                font-size: .7rem;
                position: relative;
                top:10px;
                display:inline-block;
                background:#fff;
                padding:0 2px;
            }
            .formContainer input[type="text"]{
                padding:10px;
                display:block;
                grid-column:1/4;
            }
            .submitContainer{
                padding:15px;
                grid-column:2/4;
                text-align:center;
            }
            .submitUserDetails{
                padding:15px 24px;
            }
        `
    }
    static get properties(){
        return{
            userDetails:{type:Object},
            listUserDetails: {type:Array},
            seletedPage:{type:Number,reflect: true,
                hasChanged(newVal, oldVal) {
                    console.log("Property changed");
                  }

            }
        }
    }
    
    render(){
        return html`
        <section class="user-details-form">
            <div class="formContainer">
                <label for="salutation">Salutation </label>
                <input type="text" name="salutation" @change="${this.getuserDetails}">
            </div>
            <div class="formContainer">
                <label for="firstName"> First Name </label>
                <input type="text" name="firstName" @change="${this.getuserDetails}">
            </div>
            <div class="formContainer">
                <label for="secoundName"> Secound Name </label>
                <input type="text" name="secoundName" @change="${this.getuserDetails}">
            </div>
            <div class="formContainer">
                <label for="lastName"> Last Name </label>
                <input type="text" name="lastName" @change="${this.getuserDetails}">
            </div>
            <div class="formContainer">
                <label for="address1"> Address 1</label>
                <input type="text" name="address1" @change="${this.getuserDetails}">
            </div>
            <div class="formContainer">
                <label for="address2"> Address 2</label>
                <input type="text" name="address2" @change="${this.getuserDetails}">
            </div>
            <div class="formContainer">
                <label for="landmark"> Land Mark</label>
                <input type="text" name="landmark" @change="${this.getuserDetails}">
            </div>
            <div class="formContainer">
                <label for="zipcode">Zip Code</label>
                <input type="text" name="zipcode" @change="${this.getuserDetails}">
            </div>
            <div class="formContainer">
                <label for="city">City</label>
                <input type="text" name="city" @change="${this.getuserDetails}">
            </div>
            <div class="formContainer">
                <label for="state"> State</label>
                <input type="text" name="state" @change="${this.getuserDetails}">
            </div>
            <div class="formContainer">
                <label for="country"> Country</label>
                <input type="text" name="country" @change="${this.getuserDetails}">
            </div>
            <div class="formContainer"></div>
            <div class="formContainer">
                <label for="country"> Country</label>
                <input type="text" name="country" @change="${this.getuserDetails}">
            </div>
            <div class="formContainer">
                <label for="mobileno"> Mobile Number</label>
                <input type="text" name="mobileno" @change="${this.getuserDetails}">
            </div>
            <div class="formContainer submitContainer">
            <button id="submitUserDetails" class="submitUserDetails" @click="${this.getdetails}"> Submit </button>
           
            </div>
        </form>
        `
    }
    getuserDetails(event){
        let name = event.target.name;
        this.userDetails[name]=event.target.value;
        
    }
    getdetails(){
        this.listUserDetails.push(this.userDetails);
        console.log(this.listUserDetails);
        this.seletedPage = 0;

    }
}

customElements.define('create-user',CreateUser);