import { html, css, LitElement } from 'lit-element';
import {DilePages} from 'dile-pages';
import SideNav from '../src/SideNav.js';
import MainContainer from '../src/MainContainer.js';

export class CustomerDirectory extends LitElement {
  static get styles() {
    return css`
    .mainContainer{
      display:grid;
      grid-template-columns: 300px 1fr;
    }
    `;
  }
  static get properties() {
    return {
      title: { type: String },
      counter: { type: Number },
      seletedPage:{type:Number,reflect: true}
    };
  }

  constructor() {
    super();
    this.title = 'Hey there';
    this.counter = 5;
  }

  __increment() {
    this.counter += 1;
  }

  render() {
    return html`
    <div class="mainContainer">
      <side-nav></side-nav>
      <main-container></main-container>

    </div>
  
    `;
  }
}

customElements.define('customer-directory', CustomerDirectory);