import { CustomerDirectory } from './src/CustomerDirectory.js';

window.customElements.define('customer-directory', CustomerDirectory);
